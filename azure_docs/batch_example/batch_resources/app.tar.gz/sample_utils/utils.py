def square(x):
    y = x * x
    return y
    
